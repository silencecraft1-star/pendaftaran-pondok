<svg width="10" height="10" viewBox="0 0 10 10" fill="none" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
    <path d="M5.25 9L9.25 5L5.25 1" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M0.75 9L4.75 5L0.75 1" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
<?php /**PATH C:\Ussage\WORKBENCH\pendaftaran-pondok\vendor\laravel\framework\src\Illuminate\Foundation\Providers/../resources/exceptions/renderer/components/icons/chevrons-right.blade.php ENDPATH**/ ?>