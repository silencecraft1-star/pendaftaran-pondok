import React from 'react';

// --- INTERFACE & TYPES (Diekspor untuk digunakan di Pendaftaran.tsx) ---

export interface FormData {
    nama: string;
    tanggalLahir: string;
    teleponOrangTua: string;
    alamatPribadi: string;
    namaSekolah: string;
    alamatSekolah: string;
    namaPanjangOrtu: string;
    profesiOrtu: string;
    alamatOrtu: string;
}

export interface FormComponentProps {
    formData: FormData;
    updateFormData: (fields: Partial<FormData>) => void;
    nextStep: () => void;
    prevStep: () => void;
}

// --- KOMPONEN INPUT ---

const Input: React.FC<
    React.InputHTMLAttributes<HTMLInputElement> & {
        label: string;
        name: keyof FormData;
    }
> = ({ label, name, ...rest }) => (
    <div className="mb-4">
        <label
            htmlFor={name}
            className="block text-left text-sm font-medium text-gray-700"
        >
            {label}
        </label>
        <input
            id={name}
            name={name}
            {...rest}
            className="mt-1 block w-full rounded-md border border-gray-300 p-2 shadow-sm focus:border-green-500 focus:ring-green-500 sm:text-sm"
        />
    </div>
);

// --- LANGKAH 1: Data Diri 👤 ---
export const PersonalDataForm: React.FC<FormComponentProps> = ({
    formData,
    updateFormData,
    nextStep,
}) => {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        updateFormData({
            [name as keyof FormData]: value,
        } as Partial<FormData>);
    };

    return (
        <div className="rounded-lg bg-white p-4">
            <Input
                label="Nama Lengkap Calon Santri"
                name="nama"
                value={formData.nama}
                onChange={handleChange}
                required
            />
            <Input
                label="Tanggal Lahir"
                name="tanggalLahir"
                type="date"
                value={formData.tanggalLahir}
                onChange={handleChange}
                required
            />
            <Input
                label="Telepon Orang Tua"
                name="teleponOrangTua"
                type="tel"
                value={formData.teleponOrangTua}
                onChange={handleChange}
                placeholder="Contoh: 0812xxxx"
                required
            />
            <Input
                label="Alamat Lengkap Saat Ini"
                name="alamatPribadi"
                value={formData.alamatPribadi}
                onChange={handleChange}
                required
            />
            <div className="mt-6 flex justify-end">
                <button
                    onClick={nextStep}
                    className="rounded-lg bg-green-600 px-6 py-2 font-semibold text-white shadow-md transition duration-150 hover:bg-green-700"
                >
                    Selanjutnya
                </button>
            </div>
        </div>
    );
};

// --- LANGKAH 2: Asal Sekolah 🏫 ---
export const SchoolDataForm: React.FC<FormComponentProps> = ({
    formData,
    updateFormData,
    nextStep,
    prevStep,
}) => {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        updateFormData({
            [name as keyof FormData]: value,
        } as Partial<FormData>);
    };

    return (
        <div className="rounded-lg bg-white p-4">
            <Input
                label="Nama Sekolah Asal (SD/MI/SMP/MTs)"
                name="namaSekolah"
                value={formData.namaSekolah}
                onChange={handleChange}
                required
            />
            <Input
                label="Alamat Sekolah Asal"
                name="alamatSekolah"
                value={formData.alamatSekolah}
                onChange={handleChange}
                required
            />
            <div className="mt-6 flex justify-between">
                <button
                    onClick={prevStep}
                    className="rounded-lg bg-gray-300 px-6 py-2 font-semibold text-gray-800 transition duration-150 hover:bg-gray-400"
                >
                    Sebelumnya
                </button>
                <button
                    onClick={nextStep}
                    className="rounded-lg bg-green-600 px-6 py-2 font-semibold text-white shadow-md transition duration-150 hover:bg-green-700"
                >
                    Selanjutnya
                </button>
            </div>
        </div>
    );
};

// --- LANGKAH 3: Data Orang Tua 👨‍👩‍👧‍👦 ---
export const ParentDataForm: React.FC<FormComponentProps> = ({
    formData,
    updateFormData,
    nextStep,
    prevStep,
}) => {
    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        updateFormData({
            [name as keyof FormData]: value,
        } as Partial<FormData>);
    };

    return (
        <div className="rounded-lg bg-white p-4">
            <Input
                label="Nama Panjang Ayah/Ibu/Wali"
                name="namaPanjangOrtu"
                value={formData.namaPanjangOrtu}
                onChange={handleChange}
                required
            />
            <Input
                label="Profesi Orang Tua"
                name="profesiOrtu"
                value={formData.profesiOrtu}
                onChange={handleChange}
                required
            />
            <Input
                label="Alamat Lengkap Orang Tua (Sama dengan di KTP)"
                name="alamatOrtu"
                value={formData.alamatOrtu}
                onChange={handleChange}
                required
            />
            <div className="mt-6 flex justify-between">
                <button
                    onClick={prevStep}
                    className="rounded-lg bg-gray-300 px-6 py-2 font-semibold text-gray-800 transition duration-150 hover:bg-gray-400"
                >
                    Sebelumnya
                </button>
                <button
                    onClick={nextStep}
                    className="rounded-lg bg-green-600 px-6 py-2 font-semibold text-white shadow-md transition duration-150 hover:bg-green-700"
                >
                    Selanjutnya
                </button>
            </div>
        </div>
    );
};

// --- LANGKAH 4: Konfirmasi 🎉 ---
export const ConfirmationStep: React.FC<FormComponentProps> = ({
    formData,
    prevStep,
}) => {
    const handleSubmit = () => {
        console.log('Data Pendaftaran Siap Disubmit:', formData);
        alert('Pendaftaran berhasil! Silakan cek konsol untuk melihat data.');
    };

    const SummaryField: React.FC<{
        label: string;
        value: string;
        className?: string;
    }> = ({ label, value, className = '' }) => (
        <div className={className}>
            <span className="font-medium text-gray-700">{label}:</span> {value}
        </div>
    );

    return (
        <div className="rounded-lg border border-green-200 bg-green-50 p-6">
            <h4 className="mb-4 text-center text-xl font-bold text-green-700">
                Konfirmasi Data Pendaftaran
            </h4>
            <p className="mb-6 text-center text-gray-600">
                Mohon periksa kembali semua data yang telah Anda masukkan.
            </p>

            {/* Tampilan Ringkasan Data */}
            <div className="grid grid-cols-2 gap-x-8 gap-y-3 rounded-lg bg-white p-6 text-left shadow-inner">
                <div className="col-span-2 mb-2 border-b pb-1 text-lg font-semibold">
                    Data Santri
                </div>
                <SummaryField label="Nama" value={formData.nama} />
                <SummaryField label="Tgl Lahir" value={formData.tanggalLahir} />
                <SummaryField
                    label="Alamat"
                    value={formData.alamatPribadi}
                    className="col-span-2"
                />

                <div className="col-span-2 mb-2 border-b pt-4 pb-1 text-lg font-semibold">
                    Data Sekolah
                </div>
                <SummaryField
                    label="Sekolah Asal"
                    value={formData.namaSekolah}
                />
                <SummaryField
                    label="Alamat Sekolah"
                    value={formData.alamatSekolah}
                    className="col-span-2"
                />

                <div className="col-span-2 mb-2 border-b pt-4 pb-1 text-lg font-semibold">
                    Data Orang Tua
                </div>
                <SummaryField
                    label="Nama Ortu"
                    value={formData.namaPanjangOrtu}
                />
                <SummaryField
                    label="Telepon Ortu"
                    value={formData.teleponOrangTua}
                />
                <SummaryField label="Profesi" value={formData.profesiOrtu} />
                <SummaryField
                    label="Alamat Ortu"
                    value={formData.alamatOrtu}
                    className="col-span-2"
                />
            </div>

            <div className="mt-8 flex justify-between">
                <button
                    onClick={prevStep}
                    className="rounded-lg bg-gray-300 px-6 py-2 font-semibold text-gray-800 transition duration-150 hover:bg-gray-400"
                >
                    Kembali
                </button>
                <button
                    onClick={handleSubmit}
                    className="rounded-lg bg-blue-600 px-6 py-2 font-semibold text-white shadow-md transition duration-150 hover:bg-blue-700"
                >
                    Submit Pendaftaran
                </button>
            </div>
        </div>
    );
};
